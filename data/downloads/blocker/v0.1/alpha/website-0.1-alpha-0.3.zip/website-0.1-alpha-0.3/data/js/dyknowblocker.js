function setembed(){
    var x = document.getElementById("forminput");
    var url = x.value;
    document.getElementById("target").src = url;
}